<?php declare(strict_types=1);


namespace App\Modules\Character\Domain;


use App\Modules\Generic\Domain\BaseId;

class LocationId extends BaseId
{
}
