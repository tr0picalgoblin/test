<?php

namespace App\Modules\Generic\Domain\Container;

use RuntimeException;

class NotEnoughSpaceInContainerException extends RuntimeException
{
}
