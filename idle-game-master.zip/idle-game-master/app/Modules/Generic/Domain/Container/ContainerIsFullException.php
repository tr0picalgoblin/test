<?php

namespace App\Modules\Generic\Domain\Container;

use RuntimeException;

class ContainerIsFullException extends RuntimeException
{
}
