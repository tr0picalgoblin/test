<?php

namespace App\Modules\Generic\Domain\Container;

use RuntimeException;

class ContainerSlotOutOfRangeException extends RuntimeException
{
}
