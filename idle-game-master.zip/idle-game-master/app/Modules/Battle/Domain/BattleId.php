<?php declare(strict_types=1);


namespace App\Modules\Battle\Domain;


use App\Modules\Generic\Domain\BaseId;

class BattleId extends BaseId
{
}
