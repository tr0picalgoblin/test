<?php


namespace App\Modules\Battle\Domain;


use Illuminate\Support\Collection;

class BattleTurns extends Collection
{

}
