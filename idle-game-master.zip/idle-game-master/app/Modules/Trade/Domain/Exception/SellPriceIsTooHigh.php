<?php declare(strict_types=1);


namespace App\Modules\Trade\Domain\Exception;

use RuntimeException;

class SellPriceIsTooHigh extends RuntimeException
{
}
