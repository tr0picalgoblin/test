<?php


namespace App\Traits;

trait ThrowsDice
{
    protected static function throwTwoDices(): int
    {
        return self::throwOneDice() + self::throwOneDice();
    }

    protected static function throwTreeDices(): int
    {
        return self::throwTwoDices() + self::throwOneDice();
    }

    protected static function throwOneDice(): int
    {
        return rand(1, 6);
    }
}