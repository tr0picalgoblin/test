composer install

php artisan key:generate

php artisan migrate --seed

php artisan storage:link

php-fpm