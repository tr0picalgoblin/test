@if($item)
    <img src="{{ asset($item->image_file_path) }}">
@endif
