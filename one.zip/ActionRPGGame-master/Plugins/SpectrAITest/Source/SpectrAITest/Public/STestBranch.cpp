// Fill out your copyright notice in the Description page of Project Settings.

#include "STestBranch.h"


// Sets default values
ASTestBranch::ASTestBranch()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void ASTestBranch::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ASTestBranch::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

