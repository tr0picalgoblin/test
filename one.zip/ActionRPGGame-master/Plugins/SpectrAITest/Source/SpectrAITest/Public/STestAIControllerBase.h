// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "SpectrAIController.h"
#include "STestAIControllerBase.generated.h"

/**
 * 
 */
UCLASS()
class SPECTRAITEST_API ASTestAIControllerBase : public ASpectrAIController
{
	GENERATED_BODY()
	
	
	
	
};
