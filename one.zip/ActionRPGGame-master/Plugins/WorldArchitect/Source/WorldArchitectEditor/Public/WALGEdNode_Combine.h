// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "LandscapeGraphEditor/WALandscapeGraphEdNode.h"
#include "WALGEdNode_Combine.generated.h"

/**
 * 
 */
UCLASS()
class WORLDARCHITECTEDITOR_API UWALGEdNode_Combine : public UWALandscapeGraphEdNode
{
	GENERATED_BODY()
	
	
	
	
};
