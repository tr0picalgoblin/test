// Copyright 1998-2014 Epic Games, Inc. All Rights Reserved.

#include "../AbilityFramework.h"
#include "../GAGlobalTypes.h"
#include "GACustomCalculation.h"

UGACustomCalculation::UGACustomCalculation(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}
