// Copyright 1998-2014 Epic Games, Inc. All Rights Reserved.

#include "AbilityFramework.h"
#include "AFLatentInterface.h"
UAFLatentInterface::UAFLatentInterface(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}
