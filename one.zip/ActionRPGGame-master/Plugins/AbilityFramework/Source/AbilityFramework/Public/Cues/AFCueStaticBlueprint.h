// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/Blueprint.h"
#include "AFCueStaticBlueprint.generated.h"

/**
 * 
 */
UCLASS()
class ABILITYFRAMEWORK_API UAFCueStaticBlueprint : public UBlueprint
{
	GENERATED_BODY()
	
	
	
	
};
