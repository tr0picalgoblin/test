// Copyright 1998-2014 Epic Games, Inc. All Rights Reserved.

#include "AbilityFrameworkEditor.h"



//TSharedPtr<class SGraphPin> FGAAttributePanelGraphPinFactory::CreatePin(class UEdGraphPin* InPin) const
//{
//	const UEdGraphSchema_K2* K2Schema = GetDefault<UEdGraphSchema_K2>();
//	if (InPin->PinType.PinCategory == K2Schema->PC_Struct)
//		//&& InPin->PinType.PinSubCategoryObject == FGAAttribute::StaticStruct())
//	{
//
//	}
//	return nullptr;
//}