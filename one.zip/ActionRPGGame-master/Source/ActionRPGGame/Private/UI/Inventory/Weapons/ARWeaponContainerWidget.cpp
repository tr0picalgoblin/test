// Fill out your copyright notice in the Description page of Project Settings.

#include "ARWeaponContainerWidget.h"

#include "IFItemWidget.h"

#include "ARPlayerController.h"
#include "ARCharacter.h"

#include "UI/ARUIComponent.h"


void UARWeaponContainerWidget::InitializeWeaponItems(class UARUIComponent* UIComponent)
{

}